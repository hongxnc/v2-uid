# 新的面板 [x-ui](https://github.com/sprov065/x-ui) 支持 v2-ui 的所有功能，解决了 v2-ui 存在的一些问题，并增加了总流量限制、到期时间限制等功能，v2-ui 将不再提供更新
